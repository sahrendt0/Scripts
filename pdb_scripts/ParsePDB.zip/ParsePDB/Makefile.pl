use ExtUtils::MakeMaker;
#use 5.004;

my @ppd;

if ($] >= 5.00503) {
  @ppd = (
    AUTHOR      => 'Benjamin Bulheller <mail@bulheller.com>',
    ABSTRACT    => 'Parse and extract data from PDB files',
    PREREQ_PM   => {
        'Error' => 0,
    },
  );
}

WriteMakefile(
	NAME         => 'ParsePDB',
	VERSION_FROM => 'ParsePDB.pm',
	@ppd
);

sub MY::postamble {

  return '' unless $] >= 5.00503;

<<'ESQ';

dist : ppd

ESQ
}

